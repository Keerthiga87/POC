export const USERS_META: Array<Object>=[
    {
        "key": "id",
        "label": "ID"
    },
    {
        "key": "name",
        "label": "Name"
    },
    {
        "key": "email",
        "label": "Email",
    },
    {
        "key": "phone",
        "label": "Phone",
    },
    {
        "key": "website",
        "label": "Website",
    }
]