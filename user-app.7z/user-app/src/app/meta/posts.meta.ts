export const POSTS_META: Array<Object>=[
    {
        "key": "id",
        "label": "ID"
    },
    {
        "key": "title",
        "label": "Title",
    },
    {
        "key": "body",
        "label": "Description",
    }
]